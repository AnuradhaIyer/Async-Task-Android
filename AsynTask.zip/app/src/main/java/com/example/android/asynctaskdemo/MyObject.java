package com.example.android.asynctaskdemo;

/**
 * Created by Anvit on 3/18/2017.
 */

public class MyObject {
    int X;
    int Y;
    int Z;
    int count;
    MyObject( int t, int h, int a, int c)
    {
        X = t;
        Y = h;
        Z = a;
        count = c;
    }
}
