# CMPE277-AsyncTaskDemo
This repository contains the assignment I did as a part of my School course CMPE 277 - Smartphone Application Development.

Assignment 4: AsyncTaskDemo An Android application that uses a concept of Async Task in Android to display random generated values in a ScrollView.
